These files are used for the compilation of the Visual Basic and Visual C++ examples.
The C# source code of these files is available in the parent directory.
